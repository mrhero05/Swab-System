<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style/style.admin.css">
    <title>Scheduling</title>
</head>
<body>
    <?php include '../layout/nav.admin.php';?>
    <div class="container-fluid">
        <div class="row">
            <?php  include '../layout/sidebar.admin.php'; ?>
            <div class="col-lg-10 p-4">
                <div class="schedulingContainer">
                    <h1>Scheduling</h1>
                    <div class="sched-calender">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>